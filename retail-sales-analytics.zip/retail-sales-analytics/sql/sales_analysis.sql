-- Retail Sales Analytics | MySQL 8+
CREATE DATABASE IF NOT EXISTS retail_analytics;
USE retail_analytics;

CREATE TABLE IF NOT EXISTS retail_sales (
 Order_ID VARCHAR(20) PRIMARY KEY, Order_Date DATE, Region VARCHAR(50), City VARCHAR(50),
 Category VARCHAR(50), Product VARCHAR(100), Customer_ID INT, Customer_Segment VARCHAR(50),
 Sales_Channel VARCHAR(30), Quantity INT, Unit_Price DECIMAL(10,2), Discount DECIMAL(5,2),
 Revenue DECIMAL(12,2), Profit DECIMAL(12,2), Payment_Method VARCHAR(30)
);

-- Import data into retail_sales, then run:

-- 1. Overall KPIs
SELECT ROUND(SUM(Revenue),2) Total_Revenue, ROUND(SUM(Profit),2) Total_Profit,
COUNT(DISTINCT Order_ID) Total_Orders, SUM(Quantity) Units_Sold,
ROUND(SUM(Profit)/NULLIF(SUM(Revenue),0)*100,2) Profit_Margin_Percent
FROM retail_sales;

-- 2. Monthly trend
SELECT DATE_FORMAT(Order_Date,'%Y-%m') Month, ROUND(SUM(Revenue),2) Revenue,
ROUND(SUM(Profit),2) Profit
FROM retail_sales GROUP BY DATE_FORMAT(Order_Date,'%Y-%m') ORDER BY Month;

-- 3. Category performance
SELECT Category, ROUND(SUM(Revenue),2) Revenue, ROUND(SUM(Profit),2) Profit, SUM(Quantity) Units_Sold
FROM retail_sales GROUP BY Category ORDER BY Revenue DESC;

-- 4. Regional performance
SELECT Region, ROUND(SUM(Revenue),2) Revenue, ROUND(SUM(Profit),2) Profit,
COUNT(DISTINCT Order_ID) Orders
FROM retail_sales GROUP BY Region ORDER BY Revenue DESC;

-- 5. Top products
SELECT Product, ROUND(SUM(Revenue),2) Revenue, SUM(Quantity) Units_Sold
FROM retail_sales GROUP BY Product ORDER BY Revenue DESC LIMIT 10;

-- 6. Customer segments
SELECT Customer_Segment, ROUND(SUM(Revenue),2) Revenue, ROUND(SUM(Profit),2) Profit,
COUNT(DISTINCT Customer_ID) Customers
FROM retail_sales GROUP BY Customer_Segment ORDER BY Revenue DESC;

-- 7. Channel performance
SELECT Sales_Channel, ROUND(SUM(Revenue),2) Revenue, ROUND(SUM(Profit),2) Profit,
COUNT(DISTINCT Order_ID) Orders
FROM retail_sales GROUP BY Sales_Channel ORDER BY Revenue DESC;

-- 8. Window function: product rank within category
WITH product_sales AS (
 SELECT Category, Product, SUM(Revenue) Revenue
 FROM retail_sales GROUP BY Category, Product
)
SELECT Category, Product, ROUND(Revenue,2) Revenue,
DENSE_RANK() OVER(PARTITION BY Category ORDER BY Revenue DESC) Category_Rank
FROM product_sales ORDER BY Category, Category_Rank;

-- 9. Running monthly revenue
WITH monthly AS (
 SELECT DATE_FORMAT(Order_Date,'%Y-%m') Month, SUM(Revenue) Revenue
 FROM retail_sales GROUP BY DATE_FORMAT(Order_Date,'%Y-%m')
)
SELECT Month, ROUND(Revenue,2) Revenue,
ROUND(SUM(Revenue) OVER(ORDER BY Month),2) Running_Revenue
FROM monthly ORDER BY Month;
