from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT/"data"/"retail_sales.csv", parse_dates=["Order_Date"])
df = df.drop_duplicates()
df[["Revenue","Profit","Quantity"]] = df[["Revenue","Profit","Quantity"]].apply(pd.to_numeric, errors="coerce")
df = df.dropna(subset=["Revenue","Profit","Quantity"])
out = ROOT/"images"; out.mkdir(exist_ok=True)

print("=== KPI SUMMARY ===")
print(f"Revenue: ₹{df.Revenue.sum():,.2f}")
print(f"Profit: ₹{df.Profit.sum():,.2f}")
print(f"Orders: {df.Order_ID.nunique():,}")
print(f"Units sold: {df.Quantity.sum():,}")
print(f"Profit margin: {df.Profit.sum()/df.Revenue.sum()*100:.2f}%")

category=df.groupby("Category",as_index=False).agg(Revenue=("Revenue","sum"),Profit=("Profit","sum"),Units=("Quantity","sum")).sort_values("Revenue",ascending=False)
region=df.groupby("Region",as_index=False).agg(Revenue=("Revenue","sum"),Profit=("Profit","sum"),Orders=("Order_ID","nunique")).sort_values("Revenue",ascending=False)
df["Month"]=df.Order_Date.dt.to_period("M").astype(str)
monthly=df.groupby("Month",as_index=False).agg(Revenue=("Revenue","sum"),Profit=("Profit","sum"))
top=df.groupby("Product",as_index=False).agg(Revenue=("Revenue","sum"),Units=("Quantity","sum")).sort_values("Revenue",ascending=False).head(10)

print("\n=== CATEGORY PERFORMANCE ===\n",category.to_string(index=False))
print("\n=== REGION PERFORMANCE ===\n",region.to_string(index=False))
print("\n=== TOP 10 PRODUCTS ===\n",top.to_string(index=False))

for data,x,y,title,file,rotation in [
    (monthly,"Month","Revenue","Monthly Revenue Trend","monthly_revenue_trend.png",45),
    (category,"Category","Revenue","Revenue by Category","revenue_by_category.png",30),
    (region,"Region","Revenue","Revenue by Region","revenue_by_region.png",0)]:
    plt.figure(figsize=(10,5))
    if data is monthly: plt.plot(data[x],data[y],marker="o")
    else: plt.bar(data[x],data[y])
    plt.title(title); plt.xlabel(x); plt.ylabel(y)
    if rotation: plt.xticks(rotation=rotation,ha="right")
    plt.tight_layout(); plt.savefig(out/file,dpi=150); plt.close()
