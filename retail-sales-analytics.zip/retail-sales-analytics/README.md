# Retail Sales & Customer Analytics

A portfolio-ready Data Analytics project demonstrating a complete workflow using
Python, SQL, CSV data and Power BI.

## Business Objective
Analyze retail transactions to understand revenue trends, product performance,
regional performance, customer segments, sales channels and profitability.

## Tools
Python, Pandas, Matplotlib, MySQL, Power BI, Git & GitHub.

## Dataset
The included dataset contains **1,200 synthetic transactions from 2025**.
It includes Order ID, date, region, city, category, product, customer segment,
channel, quantity, price, discount, revenue, profit and payment method.

> The dataset is synthetic and intended for learning/portfolio use.

## Structure
```text
retail-sales-analytics/
├── data/retail_sales.csv
├── python/sales_analysis.py
├── sql/sales_analysis.sql
├── powerbi/dashboard_guide.md
├── images/
├── requirements.txt
├── .gitignore
└── README.md
```

## Python
The script performs cleaning, KPI calculation, category/region analysis,
monthly trends, top-product analysis and visualization.

```bash
pip install -r requirements.txt
python python/sales_analysis.py
```

## SQL
`sales_analysis.sql` demonstrates aggregations, GROUP BY, CTEs and window
functions including category ranking and running revenue.

## Power BI
Import `data/retail_sales.csv`, create the measures and visuals described in
`powerbi/dashboard_guide.md`, then save a dashboard screenshot in `images/`.

## Business Questions
- Which categories generate the most revenue?
- Which regions generate the most profit?
- Which products are top revenue contributors?
- How does revenue change month by month?
- Which customer segment contributes the most revenue?
- How do Online and Store channels compare?
- Which products have high revenue but relatively low margins?

## Skills Demonstrated
**Data Analytics:** cleaning, EDA, KPIs, trend analysis  
**Python:** Pandas, Matplotlib  
**SQL:** aggregation, CTEs, window functions  
**Power BI:** DAX, dashboards, slicers, KPI visualization  
**Business:** converting transactional data into business questions and insights

## Author
**Simran Kumari**  
Data Analyst | Data Analytics | SQL | Python | Power BI  
GitHub: https://github.com/simranskumari
