Add your completed Power BI dashboard screenshot here as powerbi_dashboard.png.
