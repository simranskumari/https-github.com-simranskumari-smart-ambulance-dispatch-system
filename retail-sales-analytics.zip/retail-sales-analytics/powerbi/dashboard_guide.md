# Power BI Dashboard Guide

## Dashboard
**Retail Sales & Customer Analytics Dashboard**

Import `data/retail_sales.csv` into Power BI.

### DAX measures

```DAX
Total Revenue = SUM(retail_sales[Revenue])
Total Profit = SUM(retail_sales[Profit])
Total Orders = DISTINCTCOUNT(retail_sales[Order_ID])
Units Sold = SUM(retail_sales[Quantity])
Profit Margin % = DIVIDE([Total Profit], [Total Revenue], 0)
Average Order Value = DIVIDE([Total Revenue], [Total Orders], 0)
```

### Recommended visuals
- KPI cards: Revenue, Profit, Orders, Units Sold, Profit Margin
- Line chart: Monthly Revenue
- Column chart: Revenue by Category
- Bar chart: Revenue/Profit by Region
- Top 10 Products by Revenue
- Donut chart: Revenue by Sales Channel
- Matrix: Customer Segment with Revenue, Profit and Orders

### Slicers
Date, Region, Category, Customer Segment, Sales Channel, Payment Method.

Save a screenshot of your completed Power BI dashboard as
`images/powerbi_dashboard.png` for your GitHub README.
