# Drainage Blockage Detection

A beginner-friendly computer-vision prototype that analyzes a drainage
image and estimates whether it contains a potential blockage.

## How it Works

1. Reads a drainage image.
2. Converts it to grayscale.
3. Applies Gaussian blur to reduce noise.
4. Uses thresholding to identify dark regions.
5. Calculates the ratio of detected dark pixels.
6. Compares the ratio with a configurable threshold.
7. Saves a binary mask for inspection.

## Tech Stack

- Python
- OpenCV
- Basic image processing
- Computer vision concepts

## Project Structure

```
drainage-blockage-detection/
├── src/
│   └── detect_blockage.py
├── sample_data/
├── requirements.txt
├── .gitignore
└── README.md
```

## Setup

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Run

Put an image inside `sample_data/`, then run:

```bash
python src/detect_blockage.py sample_data/drainage.jpg
```

To change the detection threshold:

```bash
python src/detect_blockage.py sample_data/drainage.jpg --threshold 0.40
```

## Important Note

This is an educational prototype, not a validated municipal inspection
system. The thresholding approach can be affected by lighting, camera angle,
water, dirt, shadows, and image quality. A production system would require
a labeled dataset and a properly evaluated computer-vision model.
