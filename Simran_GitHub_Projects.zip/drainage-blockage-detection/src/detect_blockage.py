"""
Drainage Blockage Detection - image-based educational prototype.

The script uses simple computer-vision measurements to estimate whether
a drainage image contains a likely blockage. It is a demonstration and
should not be treated as a production inspection system.
"""

import argparse
from pathlib import Path

import cv2


def detect_blockage(image_path: str, threshold: float = 0.35):
    image = cv2.imread(image_path)

    if image is None:
        raise FileNotFoundError(f"Could not read image: {image_path}")

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Dark-pixel ratio is used as a simple proxy for obstruction.
    _, binary = cv2.threshold(
        blurred, 80, 255, cv2.THRESH_BINARY_INV
    )

    dark_ratio = cv2.countNonZero(binary) / binary.size
    blockage_detected = dark_ratio >= threshold

    return blockage_detected, dark_ratio, binary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("image", help="Path to a drainage image")
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.35,
        help="Dark-pixel ratio used for the demo decision"
    )
    parser.add_argument(
        "--output",
        default="blockage_mask.jpg",
        help="Output mask image"
    )
    args = parser.parse_args()

    detected, ratio, mask = detect_blockage(args.image, args.threshold)

    cv2.imwrite(args.output, mask)

    print(f"Dark-pixel ratio: {ratio:.2%}")
    print(
        "Result: POTENTIAL BLOCKAGE DETECTED"
        if detected
        else "Result: NO POTENTIAL BLOCKAGE DETECTED"
    )
    print(f"Mask saved to: {Path(args.output).resolve()}")


if __name__ == "__main__":
    main()
