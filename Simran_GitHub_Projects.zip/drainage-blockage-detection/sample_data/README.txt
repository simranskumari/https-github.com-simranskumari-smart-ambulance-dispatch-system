Place a drainage image here and name it drainage.jpg for the example command.
