# Smart Ambulance Dispatch System

A beginner-friendly IoT-inspired web application that demonstrates how an
emergency request can be matched with the nearest available ambulance using
GPS coordinates.

## Features
- Stores demo ambulance GPS coordinates.
- Checks ambulance availability.
- Calculates distance using the Haversine formula.
- Selects the nearest available ambulance.
- Provides a simple web interface and JSON API.
- Demonstrates real-time dispatch logic that can later be connected to GPS/IoT hardware.

## Tech Stack
- Python
- Flask
- HTML/CSS/JavaScript
- GPS latitude/longitude
- Haversine distance calculation

## Project Structure

```
smart-ambulance-dispatch-system/
├── app/
│   ├── __init__.py
│   ├── app.py
│   └── templates/
│       └── index.html
├── data/
├── requirements.txt
├── .gitignore
└── README.md
```

## How to Run

1. Install Python 3.10+.
2. Create a virtual environment:

```bash
python -m venv .venv
```

3. Activate it.

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

4. Install dependencies:

```bash
pip install -r requirements.txt
```

5. Run:

```bash
python app/app.py
```

6. Open `http://127.0.0.1:5000` in your browser.

## API

`GET /api/ambulances` returns the demo ambulance list.

`POST /api/dispatch`

Example JSON:
```json
{
  "latitude": 12.961,
  "longitude": 77.600
}
```

## Important Note

This is an educational prototype. It does not connect to real emergency
services, live road traffic, or real ambulance GPS hardware.
