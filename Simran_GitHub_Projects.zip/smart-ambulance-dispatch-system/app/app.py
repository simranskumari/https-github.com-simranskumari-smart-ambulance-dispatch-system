from flask import Flask, render_template, request, jsonify
from math import radians, sin, cos, sqrt, atan2

app = Flask(__name__)

# Demo ambulance locations (latitude, longitude)
AMBULANCES = [
    {"id": "AMB-101", "lat": 12.9716, "lon": 77.5946, "status": "Available"},
    {"id": "AMB-102", "lat": 12.9352, "lon": 77.6245, "status": "Available"},
    {"id": "AMB-103", "lat": 13.0358, "lon": 77.5970, "status": "Busy"},
]

def distance_km(lat1, lon1, lat2, lon2):
    """Calculate straight-line distance using the Haversine formula."""
    earth_radius = 6371
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)

    a = (
        sin(dlat / 2) ** 2
        + cos(radians(lat1))
        * cos(radians(lat2))
        * sin(dlon / 2) ** 2
    )
    return 2 * earth_radius * atan2(sqrt(a), sqrt(1 - a))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/ambulances")
def ambulances():
    return jsonify(AMBULANCES)

@app.route("/api/dispatch", methods=["POST"])
def dispatch():
    data = request.get_json()
    try:
        emergency_lat = float(data["latitude"])
        emergency_lon = float(data["longitude"])
    except (KeyError, TypeError, ValueError):
        return jsonify({"error": "Valid latitude and longitude are required."}), 400

    available = [
        ambulance for ambulance in AMBULANCES
        if ambulance["status"].lower() == "available"
    ]

    if not available:
        return jsonify({"message": "No ambulance is currently available."}), 404

    selected = min(
        available,
        key=lambda ambulance: distance_km(
            emergency_lat,
            emergency_lon,
            ambulance["lat"],
            ambulance["lon"],
        ),
    )

    distance = distance_km(
        emergency_lat,
        emergency_lon,
        selected["lat"],
        selected["lon"],
    )

    selected["status"] = "Dispatched"

    return jsonify({
        "message": "Nearest available ambulance dispatched.",
        "ambulance": selected,
        "estimated_distance_km": round(distance, 2)
    })

if __name__ == "__main__":
    app.run(debug=True)
